#ifndef __KEYS_HEAD_H
#define __KEYS_HEAD_H
#include "main_head.h"
#include "gpio_head.h"

typedef enum
{
    long_down   =0,
    void_down     ,
    short_down    ,
    none_down     ,
    cnt2_down     ,
    cnt3_down     ,
    cnt4_down     ,
}KEY_STATE;


#define KEY_MATRIX_WIDTH_ADD    1
#define KEY_MATRIX_HIGH_ADD     0


/*
    ��������
*/

typedef struct KEY_PARAM_CALSS_STR
{
    uint8_t   num;
    BitAction target_level;   //Ŀ���ƽ
    BitAction now_level;      //��ǰ��ƽ״̬
    BitAction last_level;     //�ϴε�ƽ״̬
    uint16_t  countDown_cnt;  //����ʱ������
    uint16_t  countDown_thre; //����ʱ��ֵ
    uint16_t  cnt;            //������
    uint16_t  time;           //��ʱ��
    uint16_t  time_thre;      //��ʱ����ֵ
    KEY_STATE state;          //��ʱ��״̬
    
    KEY_STATE (*logic_check)(struct KEY_PARAM_CALSS_STR*);
}KEY_PARAM_STR;

#define KEY_PARAM_CREATE(_num,_target_level,_countDown_thre,_time_thre)\
{                                                                      \
    .num                       = _num,                                 \
    .target_level              = _target_level,                        \
    .countDown_cnt             = 0,                                    \
    .countDown_thre            = _countDown_thre,                      \
    .cnt                       = 0,                                    \
    .time                      = 0,                                    \
    .time_thre                 = _time_thre,                           \
    .state                     = void_down,                            \
    .logic_check               = KEYS_LOGIC_CHECK,                     \
}


/*
    ���󰴼�
*/
typedef struct KEY_MATRIX_CLASS_STR
{
    GPIO_STR **width_gpio_str;       //����IO
    GPIO_STR **high_gpio_str;        //����
    uint8_t width;                   //��������
    uint8_t high;                    //��������
    uint8_t width_i;                 //���к�������
    uint8_t high_i;                  //������������
    KEY_PARAM_STR**keys_param;        //�����б�
    
    void (*add_param)(struct KEY_MATRIX_CLASS_STR*,KEY_PARAM_STR*);
    void (*add_gpio)(struct KEY_MATRIX_CLASS_STR*,GPIO_STR*,uint8_t);
    void (*check)(struct KEY_MATRIX_CLASS_STR*);
    void (*logic)(struct KEY_MATRIX_CLASS_STR*);
    void (*init)(struct KEY_MATRIX_CLASS_STR*);
    void (*str_init)(struct KEY_MATRIX_CLASS_STR*);
}KEY_MATRIX_STR;

void KEYS_MATRIX_STR_INIT(KEY_MATRIX_STR*key_matrix);

#define KEY_MATRIX_CLASS_CREATE(_width,_high)\
{\
    .width           = _width,               \
    .high            = _high,                \
    .width_i         = 0,                    \
    .high_i          = 0,                    \
    .str_init        = KEYS_MATRIX_STR_INIT, \
}



/*
    ��ͨ����
*/

typedef struct KEY_NORMAL_CLASS_STR
{
    GPIO_STR *gpio_str;       //����IO
    KEY_PARAM_STR *key_param;  //��������
    
    void      (*str_init)(struct KEY_NORMAL_CLASS_STR*);    //�ṹ���ʼ��
    void      (*init)(struct KEY_NORMAL_CLASS_STR*);        //��ʼ��
    BitAction (*check)(struct KEY_NORMAL_CLASS_STR*);       //�������
    KEY_STATE (*logic)(struct KEY_NORMAL_CLASS_STR*);       //�����߼�����
}KEY_NORMAL_STR;



void KEYS_NORMAL_STR_INIT(KEY_NORMAL_STR * key_normal_str);

#define KEY_NORMAL_CLASS_CREATE(_gpio,_param)\
{\
    .gpio_str                  = _gpio,                       \
    .key_param                 = _param,                      \
    .str_init                  = KEYS_NORMAL_STR_INIT,        \
}














#define KEY_STK_SIZE    100
#define KEY_TASK_PRIO   8



 
void Key_Task_Create(void);




#define ONOFF_GPIO_PORT   GPIOA
#define ONOFF_GPIO_PIN    GPIO_Pin_0

#define LFRI_GPIO_PORT    GPIOA
#define LFRI_GPIO_PIN     GPIO_Pin_1

#define WIDTH1_GPIO_PORT  GPIOA
#define WIDTH1_GPIO_PIN   GPIO_Pin_4

#define WIDTH2_GPIO_PORT  GPIOA
#define WIDTH2_GPIO_PIN   GPIO_Pin_5

#define WIDTH3_GPIO_PORT  GPIOA
#define WIDTH3_GPIO_PIN   GPIO_Pin_6

#define HIGH1_GPIO_PORT   GPIOA
#define HIGH1_GPIO_PIN    GPIO_Pin_7

#define HIGH2_GPIO_PORT   GPIOC
#define HIGH2_GPIO_PIN    GPIO_Pin_13








#endif
